print("This is example of running scripts using magic command")
